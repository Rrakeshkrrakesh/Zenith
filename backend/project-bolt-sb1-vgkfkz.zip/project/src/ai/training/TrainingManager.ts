import { PPOAgent } from '../agents/PPOAgent';
import { ZenithEnvironment } from '../environment/ZenithEnvironment';
import { PPOHyperparameters, Experience } from '../types/RLTypes';

export class TrainingManager {
  private agent: PPOAgent;
  private environment: ZenithEnvironment;
  private hyperparameters: PPOHyperparameters;
  private episodeRewards: number[];
  private episodeLengths: number[];

  constructor(stateSize: number, actionSize: number) {
    this.hyperparameters = {
      learningRate: 0.0003,
      entropyCoefficient: 0.01,
      valueFunctionCoefficient: 0.5,
      clipEpsilon: 0.2,
      batchSize: 64,
      epochs: 10
    };

    this.agent = new PPOAgent(stateSize, actionSize, this.hyperparameters);
    this.environment = new ZenithEnvironment();
    this.episodeRewards = [];
    this.episodeLengths = [];
  }

  public async trainEpisode(): Promise<{
    totalReward: number;
    episodeLength: number;
  }> {
    let state = this.environment.reset();
    let totalReward = 0;
    let done = false;
    let stepCount = 0;

    while (!done) {
      // Select action
      const action = await this.agent.selectAction(state);

      // Take action in environment
      const [nextState, reward, isDone] = this.environment.step(action);

      // Store experience
      const experience: Experience = {
        state,
        action,
        reward,
        nextState,
        done: isDone
      };
      this.agent.addExperience(experience);

      // Update state and accumulate reward
      state = nextState;
      totalReward += reward;
      stepCount++;
      done = isDone;
    }

    this.episodeRewards.push(totalReward);
    this.episodeLengths.push(stepCount);

    return {
      totalReward,
      episodeLength: stepCount
    };
  }

  public getStats(): {
    averageReward: number;
    averageLength: number;
    totalEpisodes: number;
  } {
    const averageReward = this.episodeRewards.reduce((a, b) => a + b, 0) / 
      this.episodeRewards.length;
    const averageLength = this.episodeLengths.reduce((a, b) => a + b, 0) / 
      this.episodeLengths.length;

    return {
      averageReward,
      averageLength,
      totalEpisodes: this.episodeRewards.length
    };
  }
}