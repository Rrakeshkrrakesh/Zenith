import { State, Action } from '../types/RLTypes';
import { useGameStore } from '../../store/useGameStore';

export class ZenithEnvironment {
  private initialState: State;
  private currentState: State;
  private stepCount: number;
  private maxSteps: number;

  constructor(maxSteps: number = 100) {
    this.maxSteps = maxSteps;
    this.stepCount = 0;
    
    const gameState = useGameStore.getState();
    this.initialState = {
      factors: gameState.factors,
      peaceIndex: gameState.peaceIndex,
      timestamp: Date.now()
    };
    this.currentState = { ...this.initialState };
  }

  public reset(): State {
    this.stepCount = 0;
    this.currentState = { ...this.initialState };
    return this.currentState;
  }

  public step(action: Action): [State, number, boolean] {
    this.stepCount++;
    
    // Apply action to the environment
    const gameStore = useGameStore.getState();
    if (action.valueChange !== 0) {
      gameStore.updateFactorValue(
        action.factorId,
        this.currentState.factors[action.factorId].value + action.valueChange
      );
    }
    if (action.weightChange !== 0) {
      gameStore.updateFactorWeight(
        action.factorId,
        this.currentState.factors[action.factorId].weight + action.weightChange
      );
    }

    // Update current state
    const newGameState = useGameStore.getState();
    this.currentState = {
      factors: newGameState.factors,
      peaceIndex: newGameState.peaceIndex,
      timestamp: Date.now()
    };

    // Calculate reward
    const reward = this.calculateReward(this.currentState);

    // Check if episode is done
    const done = this.stepCount >= this.maxSteps || this.currentState.peaceIndex >= 95;

    return [this.currentState, reward, done];
  }

  private calculateReward(state: State): number {
    const peaceIndexImprovement = state.peaceIndex - this.initialState.peaceIndex;
    
    // Base reward from peace index improvement
    let reward = peaceIndexImprovement;

    // Penalty for extreme values
    Object.values(state.factors).forEach(factor => {
      if (factor.value < 10 || factor.value > 90) {
        reward -= 5;
      }
    });

    // Bonus for balanced weights
    const weights = Object.values(state.factors).map(f => f.weight);
    const avgWeight = weights.reduce((a, b) => a + b, 0) / weights.length;
    const weightVariance = weights.reduce((acc, w) => acc + Math.pow(w - avgWeight, 2), 0) / weights.length;
    
    if (weightVariance < 0.1) {
      reward += 10;
    }

    return reward;
  }
}