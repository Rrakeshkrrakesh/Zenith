import { CoreFactor } from '../../types/CoreFactors';

export interface State {
  factors: Record<string, CoreFactor>;
  peaceIndex: number;
  timestamp: number;
}

export interface Action {
  factorId: string;
  valueChange: number;
  weightChange: number;
}

export interface Experience {
  state: State;
  action: Action;
  reward: number;
  nextState: State;
  done: boolean;
}

export interface PPOHyperparameters {
  learningRate: number;
  entropyCoefficient: number;
  valueFunctionCoefficient: number;
  clipEpsilon: number;
  batchSize: number;
  epochs: number;
}

export interface PolicyOutput {
  actionProbs: number[];
  value: number;
}