import * as tf from '@tensorflow/tfjs';
import { State, Action, PolicyOutput } from '../types/RLTypes';

export class PPONetwork {
  private actor: tf.LayersModel;
  private critic: tf.LayersModel;
  private stateSize: number;
  private actionSize: number;

  constructor(stateSize: number, actionSize: number) {
    this.stateSize = stateSize;
    this.actionSize = actionSize;
    this.actor = this.buildActor();
    this.critic = this.buildCritic();
  }

  private buildActor(): tf.LayersModel {
    const input = tf.layers.input({ shape: [this.stateSize] });
    const dense1 = tf.layers.dense({ units: 64, activation: 'relu' }).apply(input);
    const dense2 = tf.layers.dense({ units: 32, activation: 'relu' }).apply(dense1);
    const output = tf.layers.dense({ 
      units: this.actionSize, 
      activation: 'softmax' 
    }).apply(dense2);

    const model = tf.model({ inputs: input, outputs: output as tf.SymbolicTensor });
    model.compile({ 
      optimizer: tf.train.adam(0.001),
      loss: 'categoricalCrossentropy'
    });

    return model;
  }

  private buildCritic(): tf.LayersModel {
    const input = tf.layers.input({ shape: [this.stateSize] });
    const dense1 = tf.layers.dense({ units: 64, activation: 'relu' }).apply(input);
    const dense2 = tf.layers.dense({ units: 32, activation: 'relu' }).apply(dense1);
    const output = tf.layers.dense({ units: 1 }).apply(dense2);

    const model = tf.model({ inputs: input, outputs: output as tf.SymbolicTensor });
    model.compile({ 
      optimizer: tf.train.adam(0.001),
      loss: 'meanSquaredError'
    });

    return model;
  }

  public async predict(state: State): Promise<PolicyOutput> {
    const stateTensor = this.stateToTensor(state);
    
    const actionProbs = await this.actor.predict(stateTensor) as tf.Tensor;
    const value = await this.critic.predict(stateTensor) as tf.Tensor;

    const actionProbsArray = await actionProbs.array() as number[][];
    const valueArray = await value.array() as number[][];

    tf.dispose([stateTensor, actionProbs, value]);

    return {
      actionProbs: actionProbsArray[0],
      value: valueArray[0][0]
    };
  }

  private stateToTensor(state: State): tf.Tensor {
    const stateArray = this.flattenState(state);
    return tf.tensor2d([stateArray], [1, this.stateSize]);
  }

  private flattenState(state: State): number[] {
    const flatState: number[] = [];
    
    // Add peace index
    flatState.push(state.peaceIndex);
    
    // Add factor values and weights
    Object.values(state.factors).forEach(factor => {
      flatState.push(factor.value);
      flatState.push(factor.weight);
      
      // Add subfactor values
      factor.subFactors.forEach(subFactor => {
        flatState.push(subFactor.value);
      });
    });

    return flatState;
  }

  public async update(
    states: State[], 
    actions: Action[], 
    advantages: number[], 
    returns: number[],
    oldActionProbs: number[][]
  ): Promise<void> {
    const stateTensor = tf.tensor2d(
      states.map(state => this.flattenState(state))
    );

    // Update actor
    const actorLoss = await this.updateActor(
      stateTensor,
      actions,
      advantages,
      oldActionProbs
    );

    // Update critic
    const criticLoss = await this.updateCritic(
      stateTensor,
      returns
    );

    tf.dispose(stateTensor);

    return;
  }

  private async updateActor(
    states: tf.Tensor,
    actions: Action[],
    advantages: number[],
    oldActionProbs: number[][]
  ): Promise<number> {
    const actionsOneHot = tf.oneHot(
      actions.map(a => this.actionToIndex(a)),
      this.actionSize
    );

    const advantagesTensor = tf.tensor2d(advantages, [advantages.length, 1]);
    const oldActionProbsTensor = tf.tensor2d(oldActionProbs);

    const loss = this.actor.trainOnBatch([states], [actionsOneHot]);

    tf.dispose([actionsOneHot, advantagesTensor, oldActionProbsTensor]);

    return loss as number;
  }

  private async updateCritic(
    states: tf.Tensor,
    returns: number[]
  ): Promise<number> {
    const returnsTensor = tf.tensor2d(returns, [returns.length, 1]);
    const loss = this.critic.trainOnBatch([states], [returnsTensor]);
    tf.dispose(returnsTensor);
    return loss as number;
  }

  private actionToIndex(action: Action): number {
    // Convert action to index based on your action space definition
    // This is a simplified example
    return Math.floor(action.valueChange * 10) + 10;
  }
}