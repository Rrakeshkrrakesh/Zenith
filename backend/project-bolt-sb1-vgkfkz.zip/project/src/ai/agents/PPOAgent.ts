import { PPONetwork } from '../models/PPONetwork';
import { 
  State, 
  Action, 
  Experience,
  PPOHyperparameters 
} from '../types/RLTypes';
import * as math from 'mathjs';

export class PPOAgent {
  private network: PPONetwork;
  private hyperparameters: PPOHyperparameters;
  private experienceBuffer: Experience[];

  constructor(
    stateSize: number,
    actionSize: number,
    hyperparameters: PPOHyperparameters
  ) {
    this.network = new PPONetwork(stateSize, actionSize);
    this.hyperparameters = hyperparameters;
    this.experienceBuffer = [];
  }

  public async selectAction(state: State): Promise<Action> {
    const { actionProbs } = await this.network.predict(state);
    const actionIndex = this.sampleAction(actionProbs);
    return this.indexToAction(actionIndex);
  }

  private sampleAction(probabilities: number[]): number {
    const cumSum = probabilities.reduce(
      (acc: number[], prob: number) => {
        const sum = acc.length === 0 ? prob : acc[acc.length - 1] + prob;
        acc.push(sum);
        return acc;
      },
      []
    );

    const random = Math.random();
    return cumSum.findIndex(sum => random <= sum);
  }

  private indexToAction(index: number): Action {
    // Convert index to action based on your action space definition
    // This is a simplified example
    const valueChange = (index - 10) / 10;
    
    return {
      factorId: 'money', // This should be dynamic based on the current focus
      valueChange,
      weightChange: 0 // Could be made dynamic as well
    };
  }

  public addExperience(experience: Experience): void {
    this.experienceBuffer.push(experience);

    if (this.experienceBuffer.length >= this.hyperparameters.batchSize) {
      this.train();
    }
  }

  private async train(): Promise<void> {
    const experiences = this.experienceBuffer;
    this.experienceBuffer = [];

    const states = experiences.map(exp => exp.state);
    const actions = experiences.map(exp => exp.action);
    const rewards = experiences.map(exp => exp.reward);
    const nextStates = experiences.map(exp => exp.nextState);
    const dones = experiences.map(exp => exp.done);

    // Calculate advantages and returns
    const values = await Promise.all(
      states.map(async state => {
        const { value } = await this.network.predict(state);
        return value;
      })
    );

    const nextValues = await Promise.all(
      nextStates.map(async state => {
        const { value } = await this.network.predict(state);
        return value;
      })
    );

    const advantages = this.calculateAdvantages(
      rewards,
      values,
      nextValues,
      dones
    );

    const returns = advantages.map((advantage, i) => advantage + values[i]);

    // Get old action probabilities
    const oldActionProbs = await Promise.all(
      states.map(async state => {
        const { actionProbs } = await this.network.predict(state);
        return actionProbs;
      })
    );

    // Update network
    await this.network.update(
      states,
      actions,
      advantages,
      returns,
      oldActionProbs
    );
  }

  private calculateAdvantages(
    rewards: number[],
    values: number[],
    nextValues: number[],
    dones: boolean[]
  ): number[] {
    const gamma = 0.99;
    const lambda = 0.95;

    const advantages: number[] = new Array(rewards.length).fill(0);
    let lastGaeLambda = 0;

    for (let t = rewards.length - 1; t >= 0; t--) {
      const nextValue = t === rewards.length - 1 ? 0 : nextValues[t];
      const delta = rewards[t] + gamma * nextValue * (1 - Number(dones[t])) - values[t];
      lastGaeLambda = delta + gamma * lambda * (1 - Number(dones[t])) * lastGaeLambda;
      advantages[t] = lastGaeLambda;
    }

    return advantages;
  }
}