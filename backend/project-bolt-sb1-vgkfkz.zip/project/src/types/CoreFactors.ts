export interface CoreFactor {
  id: string;
  name: string;
  value: number;
  weight: number;
  subFactors: SubFactor[];
}

export interface SubFactor {
  id: string;
  name: string;
  value: number;
}

export type FactorId = 
  | 'money' 
  | 'career' 
  | 'health' 
  | 'relationships' 
  | 'personalGrowth' 
  | 'environment';