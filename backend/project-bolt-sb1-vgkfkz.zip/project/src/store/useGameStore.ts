import { create } from 'zustand';
import { CoreFactor, FactorId } from '../types/CoreFactors';
import { calculatePeaceIndex } from '../utils/calculations';

interface GameState {
  factors: Record<FactorId, CoreFactor>;
  peaceIndex: number;
  updateFactorWeight: (factorId: FactorId, weight: number) => void;
  updateFactorValue: (factorId: FactorId, value: number) => void;
}

export const useGameStore = create<GameState>((set) => ({
  factors: {
    money: {
      id: 'money',
      name: 'Money',
      value: 50,
      weight: 0.2,
      subFactors: [
        { id: 'income', name: 'Income', value: 50 },
        { id: 'savings', name: 'Savings', value: 50 },
      ],
    },
    career: {
      id: 'career',
      name: 'Career',
      value: 50,
      weight: 0.3,
      subFactors: [
        { id: 'satisfaction', name: 'Job Satisfaction', value: 50 },
        { id: 'growth', name: 'Career Growth', value: 50 },
      ],
    },
    health: {
      id: 'health',
      name: 'Health',
      value: 50,
      weight: 0.2,
      subFactors: [
        { id: 'physical', name: 'Physical Fitness', value: 50 },
        { id: 'mental', name: 'Mental Health', value: 50 },
      ],
    },
    relationships: {
      id: 'relationships',
      name: 'Relationships',
      value: 50,
      weight: 0.1,
      subFactors: [
        { id: 'family', name: 'Family', value: 50 },
        { id: 'friends', name: 'Friends', value: 50 },
      ],
    },
    personalGrowth: {
      id: 'personalGrowth',
      name: 'Personal Growth',
      value: 50,
      weight: 0.1,
      subFactors: [
        { id: 'learning', name: 'Learning', value: 50 },
        { id: 'hobbies', name: 'Hobbies', value: 50 },
      ],
    },
    environment: {
      id: 'environment',
      name: 'Environment',
      value: 50,
      weight: 0.1,
      subFactors: [
        { id: 'living', name: 'Living Conditions', value: 50 },
        { id: 'sustainability', name: 'Sustainability', value: 50 },
      ],
    },
  },
  peaceIndex: 50,

  updateFactorWeight: (factorId: FactorId, weight: number) =>
    set((state) => {
      const newFactors = {
        ...state.factors,
        [factorId]: {
          ...state.factors[factorId],
          weight,
        },
      };
      return {
        factors: newFactors,
        peaceIndex: calculatePeaceIndex(newFactors),
      };
    }),

  updateFactorValue: (factorId: FactorId, value: number) =>
    set((state) => {
      const newFactors = {
        ...state.factors,
        [factorId]: {
          ...state.factors[factorId],
          value,
        },
      };
      return {
        factors: newFactors,
        peaceIndex: calculatePeaceIndex(newFactors),
      };
    }),
}));