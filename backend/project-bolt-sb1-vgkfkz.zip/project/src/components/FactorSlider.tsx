import React from 'react';
import { CoreFactor } from '../types/CoreFactors';

interface FactorSliderProps {
  factor: CoreFactor;
  onWeightChange: (weight: number) => void;
  onValueChange: (value: number) => void;
}

export function FactorSlider({ factor, onWeightChange, onValueChange }: FactorSliderProps) {
  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <h3 className="text-lg font-semibold mb-2">{factor.name}</h3>
      
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700">
          Value: {factor.value}
        </label>
        <input
          type="range"
          min="0"
          max="100"
          value={factor.value}
          onChange={(e) => onValueChange(Number(e.target.value))}
          className="w-full"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Weight: {(factor.weight * 100).toFixed(0)}%
        </label>
        <input
          type="range"
          min="0"
          max="1"
          step="0.1"
          value={factor.weight}
          onChange={(e) => onWeightChange(Number(e.target.value))}
          className="w-full"
        />
      </div>

      <div className="mt-4 space-y-2">
        {factor.subFactors.map((subFactor) => (
          <div key={subFactor.id} className="flex items-center justify-between">
            <span className="text-sm text-gray-600">{subFactor.name}</span>
            <span className="text-sm font-medium">{subFactor.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}