import React from 'react';

interface PeaceIndexProps {
  value: number;
}

export function PeaceIndex({ value }: PeaceIndexProps) {
  return (
    <div className="p-6 bg-white rounded-lg shadow-md text-center">
      <h2 className="text-2xl font-bold mb-2">Peace Index</h2>
      <div className="text-4xl font-bold text-blue-600">
        {value.toFixed(1)}
      </div>
      <div className="mt-4 w-full bg-gray-200 rounded-full h-2.5">
        <div
          className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}