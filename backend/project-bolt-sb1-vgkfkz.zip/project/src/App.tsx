import React from 'react';
import { useGameStore } from './store/useGameStore';
import { FactorSlider } from './components/FactorSlider';
import { PeaceIndex } from './components/PeaceIndex';
import { FactorId } from './types/CoreFactors';

function App() {
  const { factors, peaceIndex, updateFactorWeight, updateFactorValue } = useGameStore();

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8">Zenith</h1>
        
        <div className="mb-8">
          <PeaceIndex value={peaceIndex} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(Object.keys(factors) as FactorId[]).map((factorId) => (
            <FactorSlider
              key={factorId}
              factor={factors[factorId]}
              onWeightChange={(weight) => updateFactorWeight(factorId, weight)}
              onValueChange={(value) => updateFactorValue(factorId, value)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;