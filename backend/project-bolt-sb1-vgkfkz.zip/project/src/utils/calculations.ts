import { CoreFactor } from '../types/CoreFactors';

export function calculatePeaceIndex(factors: Record<string, CoreFactor>): number {
  const totalWeight = Object.values(factors).reduce((sum, factor) => sum + factor.weight, 0);
  
  if (totalWeight === 0) return 0;

  const weightedSum = Object.values(factors).reduce(
    (sum, factor) => sum + (factor.value * factor.weight),
    0
  );

  return weightedSum / totalWeight;
}